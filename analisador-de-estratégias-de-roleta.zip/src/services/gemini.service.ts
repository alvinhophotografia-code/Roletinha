
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { StrategyValue } from '../types';

interface ExtractNumbersResponse {
  numbers: number[];
}

interface SuggestStrategyResponse {
  sequence: StrategyValue[];
}

interface GenerateInsightsResponse {
  insights: string;
}

interface AnalyzeRhythmResponse {
  analysis: string;
}

interface ApiError {
  error: string;
}

@Injectable({
  providedIn: 'root'
})
export class GeminiService {
  private http = inject(HttpClient);
  private apiUrl = '/api/gemini';

  private post<T>(action: string, payload: any): Observable<T | ApiError> {
    return this.http.post<T>(this.apiUrl, { action, payload }).pipe(
      catchError((error: HttpErrorResponse) => {
        console.error(`Error in Gemini API call for '${action}':`, error);
        const errorMessage = error.error?.error || 'Falha ao comunicar com o servidor da IA.';
        return of({ error: errorMessage });
      })
    );
  }

  extractNumbersFromImage(base64Image: string, mimeType: string): Observable<{ numbers: number[] } | ApiError> {
    const payload = { base64Image, mimeType };
    return this.post<ExtractNumbersResponse>('extractNumbersFromImage', payload).pipe(
      map(response => {
        if ('error' in response) {
          return response;
        }
        if (response && Array.isArray(response.numbers)) {
          const numbers = response.numbers.filter((n: any) => typeof n === 'number' && n >= 0 && n <= 36);
          return { numbers };
        }
        return { error: 'Formato de resposta inesperado do servidor.' };
      })
    );
  }

  suggestStrategy(results: number[], userPrompt: string): Observable<SuggestStrategyResponse | ApiError> {
    const payload = { results, userPrompt };
    return this.post<SuggestStrategyResponse>('suggestStrategy', payload);
  }

  generateInsights(
    latestResults: number[],
    priorityStrategies: any,
    dueAnalysis: any
  ): Observable<GenerateInsightsResponse | ApiError> {
    const payload = { latestResults, priorityStrategies, dueAnalysis };
    return this.post<GenerateInsightsResponse>('generateInsights', payload);
  }

  analyzeRhythm(results: number[], userPrompt: string): Observable<AnalyzeRhythmResponse | ApiError> {
    const payload = { results, userPrompt };
    return this.post<AnalyzeRhythmResponse>('analyzeRhythm', payload);
  }
}
