
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';

import { RouletteService } from '../../services/roulette.service';
import { GeminiService } from '../../services/gemini.service';
import { ToastService } from '../../services/toast.service';
import { UiLayoutService } from '../../services/ui-layout.service';
import { getNumberColor, getNumberParity } from '../../utils';
import { HelpTooltipComponent } from '../help-tooltip/help-tooltip.component';

type DisplayMode = 'color' | 'parity';

@Component({
  selector: 'app-rhythm-analyzer',
  templateUrl: './rhythm-analyzer.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule, HelpTooltipComponent],
  standalone: true,
})
export class RhythmAnalyzerComponent {
  rouletteService = inject(RouletteService);
  geminiService = inject(GeminiService);
  toastService = inject(ToastService);
  private uiLayoutService = inject(UiLayoutService);

  isMinimized = this.uiLayoutService.isMinimized('analysisRhythmAnalyzer');
  displayMode = signal<DisplayMode>('color');
  
  aiPrompt = signal('');
  isLoadingAi = signal(false);
  aiResponse = signal<string | null>(null);

  recentResults = computed(() => this.rouletteService.results().slice(0, 50));

  detectedPatterns = computed(() => {
    const results = this.rouletteService.results().slice().reverse(); // Oldest to newest
    if (results.length < 3) return { pairs: [], triplets: [] };

    const getColor = (n: number) => getNumberColor(n) === 'red' ? 'V' : getNumberColor(n) === 'black' ? 'P' : 'Z';
    const getParity = (n: number) => getNumberParity(n) === 'even' ? 'P' : getNumberParity(n) === 'odd' ? 'I' : 'Z';
    
    const analyze = (size: number, mapper: (n: number) => string) => {
        const sequences = new Map<string, number>();
        for (let i = 0; i <= results.length - size; i++) {
            const sequence = results.slice(i, i + size).map(mapper).join('-');
            sequences.set(sequence, (sequences.get(sequence) || 0) + 1);
        }
        return Array.from(sequences.entries())
            .sort((a, b) => b[1] - a[1])
            .slice(0, 3);
    };

    return {
      pairs: analyze(2, getColor),
      triplets: analyze(3, getColor)
    };
  });

  askAi(): void {
    const prompt = this.aiPrompt().trim();
    if (!prompt) {
      this.toastService.show('Por favor, insira uma pergunta para a IA.', 'warning');
      return;
    }
    this.isLoadingAi.set(true);
    this.aiResponse.set(null);

    this.geminiService.analyzeRhythm(this.rouletteService.results(), prompt)
      .pipe(finalize(() => this.isLoadingAi.set(false)))
      .subscribe(result => {
        if ('error' in result) {
          this.toastService.show(result.error, 'error');
          this.aiResponse.set('Ocorreu um erro ao obter a análise da IA.');
        } else if (result.analysis) {
          this.aiResponse.set(result.analysis);
          this.toastService.show('Análise da IA concluída.', 'success');
        }
      });
  }

  toggleMinimized(): void {
    this.uiLayoutService.toggleMinimized('analysisRhythmAnalyzer');
  }
}
