
import { ChangeDetectionStrategy, Component, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-help-tooltip',
  template: `
    <div class="relative inline-block">
      <button (click)="toggle()" (blur)="close()" class="text-muted-foreground hover:text-primary transition-colors focus:outline-none focus:ring-1 focus:ring-ring rounded-full">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
            <path d="M12 17h.01"></path>
        </svg>
      </button>
      @if (isOpen()) {
        <div class="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-3 rounded-md text-sm text-popover-foreground bg-popover border border-border shadow-lg z-10 animate-slide-in-up">
          {{ text() }}
        </div>
      }
    </div>
  `,
  styles: [`
    @keyframes slide-in-up {
      from {
        opacity: 0;
        transform: translate(-50%, 5px);
      }
      to {
        opacity: 1;
        transform: translate(-50%, 0);
      }
    }
    .animate-slide-in-up {
      animation: slide-in-up 0.2s ease-out forwards;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  standalone: true,
})
export class HelpTooltipComponent {
  text = input.required<string>();
  isOpen = signal(false);

  toggle(): void {
    this.isOpen.update(v => !v);
  }

  close(): void {
    // Timeout to allow click-away to register on other elements first if needed
    setTimeout(() => this.isOpen.set(false), 150);
  }
}
