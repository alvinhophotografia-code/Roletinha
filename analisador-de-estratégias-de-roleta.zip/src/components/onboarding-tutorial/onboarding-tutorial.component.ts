
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UiStateService } from '../../services/ui-state.service';

interface TutorialStep {
  title: string;
  content: string;
  highlightElement?: string;
}

@Component({
  selector: 'app-onboarding-tutorial',
  templateUrl: './onboarding-tutorial.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  standalone: true,
})
export class OnboardingTutorialComponent {
  private uiStateService = inject(UiStateService);
  currentStep = signal(0);

  steps: TutorialStep[] = [
    {
      title: 'Bem-vindo ao Co-piloto de Roleta!',
      content: 'Este não é apenas um analisador, é o seu assistente estratégico em tempo real. Vamos ver como dominar cada funcionalidade.',
    },
    {
      title: '1. Entrada de Dados Inteligente',
      content: 'Na aba "Entrada", registre os números da roleta. Digite um a um, ou use a IA para extrair de uma imagem. Fique de olho nas "Correlações ao Vivo" que mostram os números que mais saíram após o último sorteado.',
    },
    {
      title: '2. O Cérebro da Operação',
      content: 'Em "Estratégias", crie seus sistemas. Não sabe como começar? Peça uma sugestão à IA! Use o modo Avançado para lógicas complexas como Alvos (espera um número base para apostar em outros) ou Cíclicas (testa padrões de repetição).',
    },
    {
      title: '3. Onde Apostar Agora?',
      content: 'Esta é a sua grande vantagem! A aba "Mesa" mostra uma mesa de roleta visual que destaca, em tempo real, exatamente onde apostar na próxima rodada com base em todas as suas estratégias ativas. A cor mais intensa indica apostas com maior confluência.',
    },
    {
      title: '4. Mergulho Profundo nos Dados',
      content: 'Descubra padrões ocultos na aba "Análise". Use o Mapa de Calor para ver a Frequência ou Atraso dos números. O destaque é o "Analisador de Ritmo": veja a linha do tempo, padrões comuns, e faça perguntas em linguagem natural à IA, como "Depois de 2 vermelhos, qual cor saiu mais?".',
    },
    {
      title: '5. Laboratório de Testes Seguros',
      content: 'Na "Simulação", faça o backtest de suas ideias sem arriscar nada. Simule sua banca com sistemas de aposta como Martingale, defina metas de Stop-Loss/Take-Profit e salve suas configurações de teste para usar depois.',
    },
    {
      title: '6. Deixe com a Sua Cara',
      content: 'Em "Config", ajuste tudo ao seu gosto. Alterne o tipo de roleta, mude as cores e, mais importante, personalize quais cards de informação você quer ver em cada aba e em qual ordem. O app é seu! Boa sorte!',
    }
  ];

  nextStep(): void {
    if (this.currentStep() < this.steps.length - 1) {
      this.currentStep.update(i => i + 1);
    }
  }

  prevStep(): void {
    if (this.currentStep() > 0) {
      this.currentStep.update(i => i - 1);
    }
  }

  finish(): void {
    this.uiStateService.finishOnboarding();
  }
}
