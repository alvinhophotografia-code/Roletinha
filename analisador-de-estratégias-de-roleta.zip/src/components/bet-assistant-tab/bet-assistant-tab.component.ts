
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StrategyService } from '../../services/strategy.service';
import { UiStateService } from '../../services/ui-state.service';
import { RouletteService } from '../../services/roulette.service';
import { StrategyValue, Strategy, RouletteType } from '../../types';
import { getNumberColor, getNeighbors, RED_NUMBERS, BLACK_NUMBERS, AMERICAN_00 } from '../../utils';
import { HelpTooltipComponent } from '../help-tooltip/help-tooltip.component';

interface BetSuggestion {
  strategyName: string;
  nextStep: string;
}

@Component({
  selector: 'app-bet-assistant-tab',
  templateUrl: './bet-assistant-tab.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, HelpTooltipComponent],
  standalone: true,
})
export class BetAssistantTabComponent {
  strategyService = inject(StrategyService);
  uiStateService = inject(UiStateService);
  rouletteService = inject(RouletteService);

  rouletteType = this.uiStateService.rouletteType;
  gridNumbers = Array.from({ length: 36 }, (_, i) => i + 1);

  betSuggestions = computed(() => {
    const activeStrategies = this.strategyService.strategies().filter(s => s.active && s.sequence.length > 0);
    const totalSpins = this.rouletteService.results().length;

    const numberCoverage = new Map<number, number>();
    const areaCoverage = new Map<string, number>();
    const nextBets: BetSuggestion[] = [];

    for (const strategy of activeStrategies) {
      let nextStep: StrategyValue | null = null;

      if (strategy.sequence[0].type === 'target_numbers') {
        if (strategy.currentConsecutiveHits >= 1) {
          nextStep = strategy.sequence[0];
        }
      } else if (strategy.sequence[0].type === 'cyclical') {
        if (strategy.pendingCheck && strategy.pendingCheck.checkAtSpin === totalSpins + 1) {
            nextStep = { type: 'number_set', value: this.getNumbersForStrategyValue(strategy.sequence[0].value.target) };
        }
      } else {
        const currentIndex = strategy.currentConsecutiveHits % strategy.sequence.length;
        nextStep = strategy.sequence[currentIndex];
      }

      if (nextStep) {
        const { numbers, areas, label } = this.getBetsForStrategyValue(nextStep);
        numbers.forEach(num => numberCoverage.set(num, (numberCoverage.get(num) || 0) + 1));
        areas.forEach(area => areaCoverage.set(area, (areaCoverage.get(area) || 0) + 1));
        nextBets.push({ strategyName: strategy.name, nextStep: label });
      }
    }
    
    const maxCoverage = Math.max(1, ...Array.from(numberCoverage.values()), ...Array.from(areaCoverage.values()));

    return { numberCoverage, areaCoverage, nextBets, maxCoverage };
  });
  
  getCoverageStyle(coverage: number, maxCoverage: number): { [key: string]: string } {
      if (coverage === 0) return {};
      const intensity = Math.min(1, coverage / Math.max(1, maxCoverage));
      const alpha = 0.4 + intensity * 0.6;
      return {
        'background-color': `hsla(var(--primary), ${alpha})`,
        'border-color': `hsla(var(--primary), 1)`,
      };
  }

  getBetsForStrategyValue(value: StrategyValue): { numbers: number[], areas: string[], label: string } {
    let numbers: number[] = [];
    let areas: string[] = [];
    let label = '';

    const addRange = (start: number, end: number) => Array.from({ length: end - start + 1 }, (_, i) => start + i);

    switch (value.type) {
      case 'color':
        label = value.value === 'red' ? 'Vermelho' : value.value === 'black' ? 'Preto' : 'Verde';
        areas.push(value.value);
        if (value.value === 'red') numbers = [...RED_NUMBERS];
        if (value.value === 'black') numbers = [...BLACK_NUMBERS];
        if (value.value === 'green') numbers = [0];
        break;
      case 'parity':
        label = value.value === 'even' ? 'Par' : 'Ímpar';
        areas.push(value.value);
        for (let i = 1; i <= 36; i++) {
          if ((value.value === 'even' && i % 2 === 0) || (value.value === 'odd' && i % 2 !== 0)) {
            numbers.push(i);
          }
        }
        break;
      case 'range':
        label = value.value === 'low' ? '1-18' : '19-36';
        areas.push(value.value);
        numbers = value.value === 'low' ? addRange(1, 18) : addRange(19, 36);
        break;
      case 'dozen':
        label = value.value === 'first' ? '1ª Dúzia' : value.value === 'second' ? '2ª Dúzia' : '3ª Dúzia';
        areas.push(value.value + 'Dozen');
        if (value.value === 'first') numbers = addRange(1, 12);
        if (value.value === 'second') numbers = addRange(13, 24);
        if (value.value === 'third') numbers = addRange(25, 36);
        break;
      case 'column':
        label = value.value === 'first' ? '1ª Coluna' : value.value === 'second' ? '2ª Coluna' : '3ª Coluna';
        areas.push(value.value + 'Column');
        const start = value.value === 'first' ? 1 : value.value === 'second' ? 2 : 3;
        for (let i = start; i <= 36; i += 3) {
          numbers.push(i);
        }
        break;
      case 'single_number':
        label = `Número ${value.value}`;
        numbers = [value.value];
        break;
      case 'number_set':
        label = `Conjunto de ${value.value.length} números`;
        numbers = value.value;
        break;
      case 'neighbors':
        label = `Vizinhos de ${value.value.center} (±${value.value.count})`;
        numbers = getNeighbors(value.value.center, value.value.count, this.rouletteType());
        break;
      case 'target_numbers':
        label = `Alvos (${value.value.targets.length})`;
        numbers = value.value.targets;
        break;
    }
    return { numbers, areas, label };
  }

  getNumbersForStrategyValue(value: StrategyValue): number[] {
      return this.getBetsForStrategyValue(value).numbers;
  }
  
  getNumberColorClass(num: number): string {
    const color = getNumberColor(num);
    return color === 'red' ? 'bg-red-600' : color === 'black' ? 'bg-black' : 'bg-green-600';
  }
}
