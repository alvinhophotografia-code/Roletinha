
import { GoogleGenAI, Type } from "@google/genai";
import type { VercelRequest, VercelResponse } from '@vercel/node';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { action, payload } = req.body;

  if (!process.env.API_KEY) {
    return res.status(500).json({ error: 'API_KEY environment variable not set on the server.' });
  }
  
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    switch (action) {
      case 'extractNumbersFromImage': {
        const { base64Image, mimeType } = payload;
        const imagePart = { inlineData: { mimeType, data: base64Image } };
        const textPart = { text: `Você é um especialista em analisar resultados de roleta europeia (números de 0 a 36). Analise a imagem e extraia todos os números visíveis em ordem de aparição.` };
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [textPart, imagePart] },
            config: {
                temperature: 0,
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        numbers: {
                            type: Type.ARRAY,
                            items: { type: Type.NUMBER },
                            description: 'Uma lista de todos os números da roleta (0-36) extraídos da imagem, na ordem em que aparecem.'
                        }
                    }
                }
            }
        });
        
        return res.status(200).json(JSON.parse(response.text));
      }

      case 'suggestStrategy': {
        const { results, userPrompt } = payload;
        const latestResults = results.slice(0, 50);

        const prompt = `Com base nos seguintes resultados recentes da roleta (do mais recente para o mais antigo): ${JSON.stringify(latestResults)} e na solicitação do usuário: "${userPrompt}", gere uma nova sequência de estratégia.

INSTRUÇÕES CRÍTICAS:
1. Analise os resultados em busca de padrões relevantes para a solicitação do usuário (sequências, números quentes/frios, etc.).
2. Retorne APENAS um array JSON válido de objetos de passo de estratégia.
3. Cada objeto deve ter um 'type' e um 'value'.
4. O 'type' deve ser um dos seguintes: 'color', 'parity', 'range', 'dozen', 'column', 'single_number', 'number_set'.
5. O 'value' deve ser apropriado para o tipo (por exemplo, para 'color', o valor deve ser 'red', 'black' ou 'green'). Para 'number_set', o valor deve ser um array de números.

Exemplo de uma resposta válida para "apostar no vermelho e depois no par":
[
  {"type": "color", "value": "red"},
  {"type": "parity", "value": "even"}
]`;
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
            temperature: 0.5,
          }
        });

        return res.status(200).json({ sequence: JSON.parse(response.text) });
      }

      case 'generateInsights': {
         const { latestResults, priorityStrategies, dueAnalysis } = payload;
         const prompt = `
      Você é um analista especialista em roleta. Seu objetivo é fornecer insights acionáveis e concisos em português do Brasil.

      Com base nos dados a seguir:
      - Últimos 50 resultados (do mais recente para o mais antigo): ${JSON.stringify(latestResults)}
      - Estratégias ativas em sequências de derrota notáveis: ${JSON.stringify(priorityStrategies)}
      - Itens mais atrasados (quantas rodadas não saem): ${JSON.stringify(dueAnalysis)}

      Analise os dados e forneça um resumo em 2-3 parágrafos curtos. Foque em:
      1. Padrões óbvios ou tendências (ex: predominância de uma cor, dúzia, etc.).
      2. Estratégias que estão falhando e podem estar se aproximando de um ponto de reversão.
      3. Quais apostas (dúzias, colunas, etc.) estão significativamente atrasadas e merecem atenção.

      Seja direto e use uma linguagem clara. Não dê conselhos financeiros. Apenas apresente a análise dos dados. Formate sua resposta como texto simples, usando quebras de linha para separar os parágrafos.
    `;
         const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
         });

         return res.status(200).json({ insights: response.text });
      }
      
      case 'analyzeRhythm': {
        const { results, userPrompt } = payload;
        const latestResults = results.slice(0, 100); // Limit to last 100 results for context size
        const prompt = `
          Você é um 'Roulette Rhythm Analyst'. Sua única tarefa é analisar a sequência de números de roleta fornecida para responder à pergunta específica do usuário.
          - Baseie TODA a sua análise ESTATÍSTICA e PROBABILÍSTICA **EXCLUSIVAMENTE** na sequência de dados fornecida. Não use conhecimento geral sobre a roleta.
          - Os dados estão na ordem do mais recente para o mais antigo: ${JSON.stringify(latestResults)}.
          - Responda de forma concisa e direta à pergunta do usuário, em português do Brasil.

          Pergunta do usuário: "${userPrompt}"

          Exemplo de análise: Se a pergunta for "Depois de dois vermelhos seguidos, qual cor tem saído mais?", você deve contar as ocorrências de 'Vermelho, Vermelho' nos dados e então verificar o que veio a seguir, apresentando a contagem e a porcentagem observada.
        `;
         const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
         });

         return res.status(200).json({ analysis: response.text });
      }

      default:
        return res.status(400).json({ error: 'Invalid action' });
    }
  } catch (error: any) {
    console.error(`Error in action '${action}':`, error);
    let errorMessage = 'Ocorreu um erro ao processar a requisição.';
    if (error.message) {
        if (error.message.includes('API key not valid')) {
            errorMessage = 'A chave da API do Gemini é inválida ou não foi configurada no servidor.';
        } else if (error.message.includes('SAFETY')) {
            errorMessage = 'A requisição foi bloqueada por razões de segurança.';
        }
    }
    return res.status(500).json({ error: errorMessage });
  }
}
